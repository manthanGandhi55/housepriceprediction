import json
import numpy as np
import pickle

__model = None
__data_columns = None
__locations = None

def load_saved_artifacts():
    global __data_columns, __locations, __model
    with open("./model/columns.json", "r") as f:
        __data_columns = json.load(f)['data_columns']

    with open("./model/locations.json", "r") as f:
        __locations = json.load(f)['locations']

    with open("./model/bangalore_home_price_model.pickle", "rb") as f:
        __model = pickle.load(f)

def get_location_names():
    return [col.replace("location_", "").title() for col in __data_columns if col.startswith("location_")]
    return __locations

def predict_price(location, sqft, bath, bhk):
    try:
        loc_index = __data_columns.index("location_" + location.lower())
    except:
        loc_index = -1

    x = np.zeros(len(__data_columns))
    x[0] = sqft
    x[1] = bath
    x[2] = bhk

    if loc_index >= 0:
        x[loc_index] = 1

    return round(__model.predict([x])[0], 2)
