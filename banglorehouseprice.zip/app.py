from flask import Flask, request, render_template
import sys
import os

# Make sure we can access the util module
sys.path.append(os.path.join(os.path.dirname(__file__), "SERVER"))
import util

app = Flask(__name__)

@app.route('/')
def home():
    locations = util.get_location_names()
    return render_template('index.html', locations=locations)

@app.route('/predict', methods=['POST'])
def predict():
    location = request.form['location']
    sqft = float(request.form['sqft'])
    bath = int(request.form['bath'])
    bhk = int(request.form['bhk'])

    output = util.predict_price(location, sqft, bath, bhk)
    locations = util.get_location_names()
    return render_template('index.html', prediction_text=f'Estimated Price: ₹ {output} Lakhs', locations=locations)

if __name__ == '__main__':
    util.load_saved_artifacts()
    app.run(debug=True)
